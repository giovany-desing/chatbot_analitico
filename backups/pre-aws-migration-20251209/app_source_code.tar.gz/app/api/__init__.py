"""
Módulo de endpoints de API.
"""

